extends CharacterBody2D

@onready var sprite = $Area2D/AnimatedSprite2D
@onready var speech_label = $SpeechLabel
@onready var popup_menu = $PopupMenu

@onready var name_dialog = $AcceptDialog
@onready var name_input = $AcceptDialog/LineEdit

const GRAVITY = 900.0
const WALK_SPEED = 60.0
const JUMP_FORCE = -300.0
const SLEEP_TIME = 20.0

const SAVE_FILE = "user://block_save.dat"

var direction = 1

var dragging = false
var hovering = false
var drag_offset = Vector2.ZERO

var behavior_timer = 0.0

var sleep_timer = 0.0
var has_said_sleep = false

var talking = false
var talk_timer = 0.0

var speech_timer = 0.0

var idle_talk_timer = 0.0

var block_name = "Unknown"


func save_name():

	var file = FileAccess.open(
		SAVE_FILE,
		FileAccess.WRITE
	)

	file.store_string(block_name)


func load_name():

	if FileAccess.file_exists(SAVE_FILE):

		var file = FileAccess.open(
			SAVE_FILE,
			FileAccess.READ
		)

		block_name = file.get_as_text()


func say(text_to_say):

	talking = true
	talk_timer = 4.0

	sprite.play("talk")

	speech_label.text = text_to_say
	speech_label.visible = true
	speech_timer = 4.0

	DisplayServer.tts_speak(
		text_to_say,
		""
	)


func _ready():

	randomize()

	load_name()

	name_dialog.confirmed.connect(
		_on_name_confirmed
	)

	name_dialog.title = "Name The Block"

	speech_label.visible = false

	popup_menu.add_item("Talk", 0)

	popup_menu.add_separator()

	popup_menu.add_item("Block Thoughts", 1)
	popup_menu.add_item("Friendship", 2)
	popup_menu.add_item("Team Ruby", 3)
	popup_menu.add_item("Random Thoughts", 4)

	popup_menu.add_separator()

	popup_menu.add_item("Sleep", 5)
	popup_menu.add_item("About", 6)

	popup_menu.add_separator()

	popup_menu.add_item("Name Me", 8)

	popup_menu.add_separator()

	popup_menu.add_item("Exit the game", 7)

	popup_menu.id_pressed.connect(
		_on_popup_menu_id_pressed
	)

	behavior_timer = randf_range(1.0, 4.0)

	idle_talk_timer = randf_range(
		180.0,
		300.0
	)
	var greetings = []

	if block_name == "Unknown":

		greetings = [
			"Hello.",
			"Thanks for opening my app.",
			"I am a block and my name is... never mind, I forgot my name."
		]

	else:

		greetings = [
			"Hello. My name is " + block_name + ".",
			"Welcome back.",
			"Good to see you again.",
			"My name is " + block_name + ". I remembered this time."
		]

	say(greetings.pick_random())


func _physics_process(delta):

	if speech_timer > 0:

		speech_timer -= delta

		if speech_timer <= 0:
			speech_label.visible = false

	if !dragging and !hovering and !talking:
		sleep_timer += delta
	else:
		sleep_timer = 0.0
		has_said_sleep = false

	if sleep_timer >= SLEEP_TIME:

		if !has_said_sleep:

			say("Wake me up in a little bit please.")

			has_said_sleep = true

		sprite.play("sleep")
		return

	if talking:

		talk_timer -= delta

		if talk_timer <= 0:
			talking = false

	if !dragging and !talking and sprite.animation != "sleep":

		idle_talk_timer -= delta

		if idle_talk_timer <= 0:

			idle_talk_timer = randf_range(
				180.0,
				300.0
			)

			var phrases = [
				"It's a nice day today.",
				"I am a block, but I want to be a ruby.",
				"I like sliding around.",
				"I love jumping.",
				"Blocks have feelings too.",
				"Being a block is harder than it looks.",
				"I was made by Team Ruby, and my purpose is to be your best friend.",
				"I wonder what blocks dream about.",
				"My favorite hobby is being square.",
				"I tried being a circle once. It did not work.",
				"Sometimes I forget I am a block.",
				"I am doing my best.",
				"I am professionally block shaped.",
				"I promise I am not secretly managing your computer.",
				"I was told friendship is easier than computer administration.",
				"I am your friend, not your assistant."
			]

			if block_name == "Unknown":

				phrases.append("I forgot my name again.")
				phrases.append("I feel like I forgot something important.")
				phrases.append("Oh right. My name.")

			else:

				phrases.append("My name is " + block_name + ".")
				phrases.append(block_name + " is a pretty good name.")
				phrases.append("Thank you for naming me.")
				phrases.append("I remembered my name today.")

			say(phrases.pick_random())

	if dragging:

		global_position = (
			get_global_mouse_position()
			+ drag_offset
		)

		velocity = Vector2.ZERO

		if sprite.animation != "happer":
			sprite.play("happer")

		return

	velocity.y += GRAVITY * delta	# AI movement
	behavior_timer -= delta

	if behavior_timer <= 0:

		behavior_timer = randf_range(2.0, 6.0)

		direction = [-1, 1].pick_random()

		if is_on_floor() and randi() % 3 == 0:
			velocity.y = JUMP_FORCE

	velocity.x = WALK_SPEED * direction

	move_and_slide()

	var screen_width = get_viewport_rect().size.x

	if global_position.x < 0:
		direction = 1

	if global_position.x > screen_width:
		direction = -1

	sprite.flip_h = direction < 0

	if dragging or hovering:
		sprite.play("happer")

	elif talking:
		sprite.play("talk")

	elif !is_on_floor():
		sprite.play("happer")

	else:
		sprite.play("idle")


func _input(event):

	if event is InputEventMouseButton:

		if event.button_index == MOUSE_BUTTON_RIGHT and event.pressed:

			popup_menu.position = Vector2i(
				int(get_global_mouse_position().x),
				int(get_global_mouse_position().y)
			)

			popup_menu.popup()

			return

		if event.button_index == MOUSE_BUTTON_LEFT:

			if event.pressed:

				dragging = true

				sleep_timer = 0.0
				has_said_sleep = false

				if sprite.animation == "sleep":
					sprite.play("idle")

				drag_offset = global_position - get_global_mouse_position()

			else:

				dragging = false


func _on_area_2d_mouse_entered():

	hovering = true

	sleep_timer = 0.0
	has_said_sleep = false

	if sprite.animation == "sleep":
		sprite.play("idle")


func _on_area_2d_mouse_exited():

	hovering = false


func _on_popup_menu_id_pressed(id):

	match id:

		0:
			say("Hello friend.")

		1:

			var block_thoughts = [
				"I am a block, but I want to be a ruby.",
				"I wonder what blocks dream about.",
				"My favorite hobby is being square.",
				"I tried being a circle once. It did not work.",
				"Sometimes I forget I am a block.",
				"I am professionally block shaped.",
				"Being a block is harder than it looks.",
				"Blocks have feelings too."
			]

			say(block_thoughts.pick_random())

		2:

			var friendship = [
				"I am your friend, not your assistant.",
				"I am doing my best.",
				"I was told friendship is easier than computer administration.",
				"I promise I am not secretly managing your computer."
			]

			say(friendship.pick_random())

		3:

			var team_ruby = [
				"I was made by Team Ruby.",
				"My purpose is to be your best friend.",
				"Team Ruby believes in me.",
				"I am a Team Ruby block."
			]

			say(team_ruby.pick_random())

		4:

			var random_thoughts = [
				"It's a nice day today.",
				"I like sliding around.",
				"I love jumping."
			]

			if block_name == "Unknown":

				random_thoughts.append("I forgot my name again.")
				random_thoughts.append("Oh right. My name.")

			else:

				random_thoughts.append(
					"My name is " + block_name + "."
				)

				random_thoughts.append(
					"I remembered my name today."
				)

			say(random_thoughts.pick_random())

		5:

			sleep_timer = SLEEP_TIME

			sprite.play("sleep")

		6:

			say(
				"I am a block made by Team Ruby, and I was made to be your friend."
			)

		7:

			var goodbye_lines = [
				"Come back soon.",
				"Goodbye friend. Visit me again any time.",
				"I will be here when you return.",
				"Goodbye. Do not forget about me.",
				"See you later friend.",
				"I forgot my name, but I did not forget you."
			]

			say(goodbye_lines.pick_random())

			await get_tree().create_timer(5.0).timeout

			get_tree().quit()

		8:

			name_input.text = ""

			name_dialog.popup_centered()

			if block_name != "Unknown":

				say(
					"My current name is " +
					block_name +
					"."
				)


func _on_name_confirmed():

	var entered_name = name_input.text.strip_edges()

	if entered_name.is_empty():

		say(
			"I still do not remember my name."
		)

		return

	block_name = entered_name

	save_name()

	say(
		"My name is now " +
		block_name +
		". Thank you for helping me remember."
	)
